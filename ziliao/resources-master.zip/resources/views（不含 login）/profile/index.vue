<template>
  <div class="">个人中心</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped></style>
