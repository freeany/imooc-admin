/**
 * 返回随机色值
 * @returns
 */
